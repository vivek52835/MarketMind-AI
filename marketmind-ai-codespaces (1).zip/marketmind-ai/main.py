import argparse
from app.data.market_data import download_history
from app.features.technical import add_indicators
from app.signals.signal_engine import generate_signal

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", default="GC=F", help="Yahoo Finance symbol, e.g. GC=F or EURUSD=X")
    parser.add_argument("--period", default="1y")
    args = parser.parse_args()

    df = add_indicators(download_history(args.symbol, args.period))
    result = generate_signal(df)

    print("\n=== MarketMind AI ===")
    print(f"Symbol:     {args.symbol}")
    print(f"Close:      {result['close']}")
    print(f"RSI:        {result['rsi']}")
    print(f"Signal:     {result['signal']}")
    print(f"Confidence: {result['confidence']:.0%}")
    print("Evidence:")
    for reason in result["reasons"]:
        print(f"  - {reason}")
    print("\nThis is a baseline research signal, not a guaranteed prediction.\n")

if __name__ == "__main__":
    main()
