import streamlit as st
from app.data.market_data import download_history
from app.features.technical import add_indicators
from app.signals.signal_engine import generate_signal

st.set_page_config(page_title="MarketMind AI", layout="wide")
st.title("MarketMind AI")
st.caption("Research and paper-trading dashboard — not financial advice.")

symbol = st.text_input("Market symbol", "GC=F")
period = st.selectbox("History", ["6mo", "1y", "2y", "5y"], index=1)

if st.button("Analyze"):
    try:
        df = add_indicators(download_history(symbol, period=period))
        result = generate_signal(df)
        c1, c2, c3 = st.columns(3)
        c1.metric("Signal", result["signal"])
        c2.metric("Confidence", f"{result['confidence']:.0%}")
        c3.metric("RSI", result["rsi"])
        st.line_chart(df[["close", "ema_20", "sma_20", "sma_50"]].dropna())
        st.subheader("Evidence")
        for reason in result["reasons"]:
            st.write("•", reason)
    except Exception as exc:
        st.error(str(exc))
