# MarketMind AI

A GitHub Codespaces-ready research platform for multi-market analysis.

## Phase 1

- Historical market-data ingestion through Yahoo Finance
- Technical indicators
- Baseline BUY/SELL/HOLD bias engine
- Streamlit dashboard
- Unit test foundation

The current signal engine is deliberately simple. It is **not** a trained AI predictor and it does not guarantee market direction.

## Run in GitHub Codespaces

Open the repository in GitHub Codespaces. The dev container installs dependencies automatically.

### Command line

```bash
python main.py --symbol GC=F --period 1y
```

Examples:

```bash
python main.py --symbol EURUSD=X
python main.py --symbol SI=F
python main.py --symbol ^GSPC
```

### Dashboard

```bash
streamlit run dashboard/app.py
```

Then open port 8501.

### Tests

```bash
pytest -q
```

## Planned phases

1. Market data + technical features
2. ML classification and walk-forward validation
3. News and sentiment ingestion
4. Macro/economic event features
5. Ensemble prediction
6. Realistic backtesting
7. FastAPI
8. Dashboard expansion
9. Paper trading
10. Model monitoring

## Reliability principles

- No look-ahead bias
- No future-data leakage
- Timestamp all external data
- Backtest with costs/slippage
- Paper trading before any live execution
- Treat probabilities as model estimates, not certainty

## Disclaimer

This project is for software research and educational purposes. Financial markets are uncertain and losses are possible. Do your own due diligence before making financial decisions.
