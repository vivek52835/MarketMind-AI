from __future__ import annotations
import pandas as pd

def generate_signal(df: pd.DataFrame) -> dict:
    """Simple baseline signal. This is not a trained predictive model."""
    row = df.dropna().iloc[-1]
    score = 0
    reasons = []

    if row["close"] > row["ema_20"]:
        score += 1
        reasons.append("price above EMA20")
    else:
        score -= 1
        reasons.append("price below EMA20")

    if row["sma_20"] > row["sma_50"]:
        score += 1
        reasons.append("SMA20 above SMA50")
    else:
        score -= 1
        reasons.append("SMA20 below SMA50")

    if row["macd"] > row["macd_signal"]:
        score += 1
        reasons.append("MACD above signal")
    else:
        score -= 1
        reasons.append("MACD below signal")

    if row["rsi_14"] > 55:
        score += 1
        reasons.append("positive RSI momentum")
    elif row["rsi_14"] < 45:
        score -= 1
        reasons.append("negative RSI momentum")
    else:
        reasons.append("RSI neutral")

    if score >= 2:
        signal = "BUY_BIAS"
    elif score <= -2:
        signal = "SELL_BIAS"
    else:
        signal = "HOLD"

    confidence = min(0.95, 0.50 + abs(score) * 0.10)

    return {
        "signal": signal,
        "confidence": round(confidence, 2),
        "score": score,
        "rsi": round(float(row["rsi_14"]), 2),
        "close": round(float(row["close"]), 4),
        "reasons": reasons,
    }
