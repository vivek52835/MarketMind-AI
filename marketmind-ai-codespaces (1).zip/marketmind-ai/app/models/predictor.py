"""Reserved for trained ML models in later phases."""

def predict(*args, **kwargs):
    raise NotImplementedError(
        "ML prediction is not enabled in Phase 1. Use the baseline signal engine."
    )
