from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "MarketMind AI"
    data_provider: str = "yfinance"
    default_period: str = "1y"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
