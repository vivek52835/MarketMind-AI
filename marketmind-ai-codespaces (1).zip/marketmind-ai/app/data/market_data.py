from __future__ import annotations
import pandas as pd
import yfinance as yf

def download_history(symbol: str, period: str = "1y", interval: str = "1d") -> pd.DataFrame:
    """Download historical OHLCV data. Symbol format follows the provider."""
    df = yf.download(symbol, period=period, interval=interval, auto_adjust=False, progress=False)
    if df.empty:
        raise ValueError(f"No market data returned for {symbol}")
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    df.columns = [str(c).lower() for c in df.columns]
    return df.dropna()
