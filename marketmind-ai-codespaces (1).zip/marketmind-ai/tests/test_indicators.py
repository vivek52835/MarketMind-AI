import pandas as pd
from app.features.technical import add_indicators

def test_indicators_are_created():
    n = 80
    close = pd.Series(range(1, n + 1), dtype=float)
    df = pd.DataFrame({
        "open": close,
        "high": close + 1,
        "low": close - 1,
        "close": close,
        "volume": 1000
    })
    out = add_indicators(df)
    for col in ["sma_20", "sma_50", "ema_20", "rsi_14", "macd", "macd_signal", "atr_14"]:
        assert col in out.columns
